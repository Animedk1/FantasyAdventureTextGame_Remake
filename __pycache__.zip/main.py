from backend import startMenu

def main():
    startMenu()

if __name__ == "__main__":
    main()
