Welcome to the game!

This Readme is both and introduction and a guide that will allow you to both understand how to play the game and how to utilize the framework to create your own text based game
